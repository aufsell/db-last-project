"""Подключение и безопасное выполнение запросов через параметры psycopg2."""

from contextlib import contextmanager

import psycopg2
from psycopg2.extras import RealDictCursor


class DbConnection:
    def __init__(self, config):
        self.config = config
        self.conn = None
        self._in_transaction = False

    def connect(self):
        if self.conn is None or self.conn.closed:
            self.conn = psycopg2.connect(
                dbname=self.config.dbname,
                user=self.config.user,
                password=self.config.password,
                host=self.config.host,
                port=self.config.port,
                connect_timeout=5,
            )
        return self.conn

    def _execute(self, query, params, mode):
        with self.connect().cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(query, params)
            if mode == "one":
                return cur.fetchone()
            if mode == "all":
                return cur.fetchall()
        return None

    def execute(self, query, params=(), mode="none"):
        """Безопасный SQL и автоматические COMMIT / ROLLBACK."""
        if self._in_transaction:
            return self._execute(query, params, mode)
        with self.connect():
            return self._execute(query, params, mode)

    @contextmanager
    def transaction(self):
        """Группировка нескольких операций в атомарную транзакцию."""
        conn = self.connect()
        if self._in_transaction:
            # Вложенных транзакций приложение не создаёт.
            raise RuntimeError("Вложенная транзакция недопустима")
        self._in_transaction = True
        try:
            with conn:
                yield
        finally:
            self._in_transaction = False

    def close(self):
        if self.conn is not None and not self.conn.closed:
            self.conn.close()
