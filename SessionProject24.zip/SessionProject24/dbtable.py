"""Базовый класс таблиц из эталонного проекта."""

from psycopg2 import sql


class DbTable:
    def __init__(self, dbconn):
        self.dbconn = dbconn

    @property
    def table(self):
        # Нельзя конкатенировать имена таблиц с пользовательским вводом.
        # sql.Identifier корректно экранирует идентификаторы.
        return sql.SQL("{}.{}").format(
            sql.Identifier(self.dbconn.config.schema),
            sql.Identifier(self.table_name),
        )

    def query(self, query, params=(), mode="none"):
        return self.dbconn.execute(query, params, mode)
