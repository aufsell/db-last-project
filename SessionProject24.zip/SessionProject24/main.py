# Левченко Ярослав Алексеевич
# Вариант 24
# Сессионный проект: сайт знакомств, таблицы «Пользователи» и «Анкеты».

"""Консольное приложение по образцу эталонного ProjectPostgreSQL."""

from getpass import getpass
import sys

import yaml
import psycopg2
from psycopg2 import errors

from dbconnection import DbConnection
from project_config import ProjectConfig
from tables.profiles_table import ProfilesTable
from tables.users_table import UsersTable
from validation import (
    birth_date, email, hash_password, last_visit, login, plain_text, rating,
)


class Cancelled(Exception):
    """Пользователь отменил действие через :q."""


MISSING = object()
FAILED = object()


def ask(label, parser, default=MISSING, nullable=False):
    """Универсальный ввод: пусто = сохранить старое / NULL у необязательного.

    :q — отмена действия, '-' — очистить необязательное поле при редактировании.
    """
    while True:
        suffix = ""
        if default is not MISSING:
            suffix = f" [текущее: {default if default is not None else 'пусто'}]"
        print(f"{label}{suffix}")
        raw = input("  > ").strip()
        if raw == ":q":
            raise Cancelled
        if raw == "":
            if default is not MISSING:
                return default
            if nullable:
                return None
            print("Поле обязательно для заполнения.")
            continue
        if raw == "-" and nullable:
            return None
        try:
            return parser(raw)
        except ValueError as exc:
            print(f"Ошибка: {exc}")


def ask_password(edit=False):
    while True:
        value = getpass("Новый пароль (пусто — сохранить; :q — отмена): " if edit
                        else "Пароль (минимум 8 символов; :q — отмена): ")
        if value == ":q":
            raise Cancelled
        if not value and edit:
            return None
        try:
            return hash_password(value)
        except ValueError as exc:
            print(f"Ошибка: {exc}")


def text_field(label, max_chars):
    return lambda value: plain_text(value, label, max_chars)


def input_user(current=None):
    """Ввод данных пользователя. Служебный user_id никогда не запрашивается."""
    current = current or {}
    initial = not current
    data = {}
    fields = (
        ("login", "Логин", login, False),
        ("name", "Имя / ФИО", text_field("Имя / ФИО", 100), False),
        ("gender", "Пол", text_field("Пол", 30), False),
        ("birth_date", "Дата рождения (ГГГГ-ММ-ДД)", birth_date, False),
        ("country", "Страна", text_field("Страна", 100), False),
        ("city", "Город", text_field("Город", 100), False),
        ("email", "Email", email, False),
        ("last_visit", "Последнее посещение (ГГГГ-ММ-ДД ЧЧ:ММ+03:00)", last_visit, True),
        ("rating_position", "Место в рейтинге (целое число)", rating, True),
    )
    for field, label, parser, nullable in fields:
        existing = current.get(field, MISSING)
        data[field] = ask(label, parser, existing, nullable)
    password = ask_password(edit=not initial)
    if password is not None:
        data["password_hash"] = password
    return data


def input_profile(current=None):
    current = current or {}
    fields = (
        ("about_me", "Описание анкеты", text_field("Описание анкеты", 5000)),
        ("hobbies", "Увлечения", text_field("Увлечения", 2000)),
        ("housing_type", "Тип проживания", text_field("Тип проживания", 100)),
    )
    data = {}
    for key, label, parser in fields:
        data[key] = ask(label, parser, current.get(key, MISSING))
    return data


class Main:
    PAGE_SIZE = 5

    def __init__(self):
        self.config = ProjectConfig()
        self.connection = DbConnection(self.config)
        self.users = UsersTable(self.connection)
        self.profiles = ProfilesTable(self.connection, self.users)

    def db_init(self):
        self.users.create()
        self.profiles.create()

    def db_drop(self):
        self.profiles.drop()
        self.users.drop()

    def db_insert_somethings(self):
        # Осмысленные вымышленные тестовые данные из ДЗ 2.
        demo = [
            ("anna_s", "Анна Смирнова", "женский", "1999-04-15", "Россия", "Москва",
             "anna-smirnova@example.com", "Люблю путешествовать и открывать новое.",
             "Походы, фотография, чтение", "Своя квартира"),
            ("ivan_p", "Иван Петров", "мужской", "1997-08-09", "Россия", "Санкт-Петербург",
             "ivan.petrov@example.com", "Ценю живое общение.",
             "Велосипед, музыка, кино", "Съёмная квартира"),
            ("maria_k", "Мария Кузнецова", "женский", "2001-02-23", "Россия", "Казань",
             "maria-k@example.com", "Люблю уютные кафе.",
             "Рисование, йога, книги", "Живу с родителями"),
            ("dmitry_o", "Дмитрий Орлов", "мужской", "1995-11-06", "Россия", "Ростов-на-Дону",
             "dmitry-orlov@example.com", "Предпочитаю активный отдых.",
             "Бег, футбол, туризм", "Частный дом"),
            ("elena_v", "Елена Волкова", "женский", "1998-06-30", "Россия", "Краснодар",
             "elena.volkova@example.com", "Ценю доброту и юмор.",
             "Театр, кулинария, плавание", "Своя квартира"),
            ("artem_m", "Артём Морозов", "мужской", "2000-12-12", "Россия", "Новосибирск",
             "artem-morozov@example.com", "Люблю учиться новому.",
             "Настольные игры, программирование", "Общежитие"),
        ]
        # Каждая запись добавляется отдельно, чтобы не зависеть от значений IDENTITY.
        for n, (username, name, gender, birthday, country, city, mailbox,
                about, hobbies, housing) in enumerate(demo, start=1):
            user_id = self.users.insert_one({
                "login": username,
                "password_hash": hash_password(f"DemoPassword-{n}-2026"),
                "name": name,
                "gender": gender,
                "birth_date": birth_date(birthday),
                "country": country,
                "city": city,
                "email": mailbox,
                "last_visit": None,
                "rating_position": n,
            })
            self.profiles.insert_one(user_id, {
                "about_me": about,
                "hobbies": hobbies,
                "housing_type": housing,
            })

    def action(self, func):
        """Понятная ошибка и сохранение работоспособности интерфейса."""
        try:
            return func()
        except Cancelled:
            print("Операция отменена.")
        except errors.UniqueViolation:
            print("Ошибка: такой логин, email или анкета уже существует.")
        except errors.ForeignKeyViolation:
            print("Операция не выполнена: запись связана с другими данными.")
        except errors.CheckViolation:
            print("Ошибка: значение нарушает ограничения таблицы.")
        except errors.StringDataRightTruncation:
            print("Ошибка: значение слишком длинное для поля таблицы.")
        except errors.UndefinedColumn:
            print("Структура таблиц не совпадает с проектом. Используйте отдельную пустую БД.")
        except psycopg2.OperationalError:
            print("Нет соединения с PostgreSQL. Проверьте config.yaml, запущена ли БД и доступен ли сервер.")
        except psycopg2.Error as exc:
            print(f"Ошибка БД (код {exc.pgcode or 'неизвестен'}). Действие отменено; данные не повреждены.")
        except (OSError, ValueError) as exc:
            print(f"Ошибка: {exc}")
        return FAILED

    def add_user(self):
        print("Новый пользователь. В любой момент :q — отмена.")
        data = input_user()
        self.users.insert_one(data)
        print("Пользователь добавлен.")

    def edit_user(self, user):
        print(f"Редактирование {user['login']}. Пустая строка сохраняет значение, '-' очищает необязательное поле.")
        data = input_user(user)
        if self.users.update_one(user["user_id"], data):
            print("Данные пользователя обновлены.")
        else:
            print("Пользователь больше не найден.")

    def delete_user(self, user):
        print(f"Удалить пользователя «{user['login']}» вместе с его анкетой?")
        if input("Напишите УДАЛИТЬ для подтверждения: ").strip() != "УДАЛИТЬ":
            print("Удаление отменено.")
            return
        if self.users.delete_one(user["user_id"]):
            print("Пользователь удалён. Связанная анкета удалена автоматически.")
        else:
            print("Пользователь больше не найден.")

    def show_profiles_by_user(self, user):
        while True:
            user_now = self.users.get(user["user_id"])
            if user_now is None:
                print("Пользователь больше не найден.")
                return
            profiles = self.profiles.all_by_user_id(user["user_id"])
            print(f"\nАнкета пользователя: {user_now['name']} ({user_now['login']})")
            if profiles:
                profile = profiles[0]
                print(f"  О себе: {profile['about_me']}")
                print(f"  Увлечения: {profile['hobbies']}")
                print(f"  Проживание: {profile['housing_type']}")
            else:
                print("  Анкета пока не создана.")
            print("1 — добавить анкету | 2 — изменить | 3 — удалить | 0 — назад")
            choice = input("=> ").strip()
            if choice == "0":
                return
            if choice == "1":
                if profiles:
                    print("У пользователя уже есть анкета (не больше одной).")
                    continue
                def add():
                    self.profiles.insert_one(user["user_id"], input_profile())
                    print("Анкета создана.")
                self.action(add)
            elif choice == "2":
                if not profiles:
                    print("Сначала создайте анкету.")
                    continue
                def edit():
                    data = input_profile(profiles[0])
                    if self.profiles.update_one(user["user_id"], data):
                        print("Анкета изменена.")
                    else:
                        print("Анкета не найдена.")
                self.action(edit)
            elif choice == "3":
                if not profiles:
                    print("Удалять нечего.")
                    continue
                if input("Напишите УДАЛИТЬ для удаления анкеты: ").strip() == "УДАЛИТЬ":
                    result = self.action(lambda: self.profiles.delete_one(user["user_id"]))
                    if result is FAILED:
                        pass
                    elif result:
                        print("Анкета удалена.")
                    else:
                        print("Анкета уже отсутствует.")
                else:
                    print("Удаление отменено.")
            else:
                print("Неизвестная команда. Выберите пункт меню.")

    def selected_user(self, rows):
        if not rows:
            print("На странице нет записей.")
            return None
        value = input(f"Номер строки на текущей странице (1–{len(rows)}, 0 — отмена): ").strip()
        if value == "0":
            return None
        if not value.isdecimal() or not (1 <= int(value) <= len(rows)):
            print("Неверный номер строки.")
            return None
        return rows[int(value) - 1]

    def show_people(self):
        page = 1
        while True:
            total = self.users.count()
            max_page = max(1, (total + self.PAGE_SIZE - 1) // self.PAGE_SIZE)
            page = min(page, max_page)
            rows = self.users.page(self.PAGE_SIZE, (page - 1) * self.PAGE_SIZE)
            print(f"\nПОЛЬЗОВАТЕЛИ — страница {page}/{max_page}; всего {total}")
            print(" №  Логин           Имя / ФИО             Город               Email")
            for i, row in enumerate(rows, 1):
                print(f" {i:<2} {row['login']:<15} {row['name']:<21} "
                      f"{row['city']:<19} {row['email']}")
            if not rows:
                print("Записей пока нет.")
            print("a — добавить | e — редактировать | d — удалить | r — анкета")
            print("n — далее | p — назад | 0 — главное меню | 9 — выход")
            choice = input("=> ").strip().lower()
            if choice == "0":
                return False
            if choice == "9":
                return True
            if choice == "n":
                if page < max_page:
                    page += 1
                else:
                    print("Это последняя страница.")
            elif choice == "p":
                if page > 1:
                    page -= 1
                else:
                    print("Это первая страница.")
            elif choice == "a":
                self.action(self.add_user)
            elif choice in ("e", "d", "r"):
                user = self.selected_user(rows)
                if user is None:
                    continue
                if choice == "e":
                    self.action(lambda: self.edit_user(user))
                elif choice == "d":
                    self.action(lambda: self.delete_user(user))
                else:
                    self.action(lambda: self.show_profiles_by_user(user))
            else:
                print("Неизвестная команда. Выберите пункт меню.")

    def reset_and_demo(self):
        print("ВНИМАНИЕ: данные users и profiles будут удалены! Другие таблицы не трогаем.")
        if input("Напишите СБРОС для подтверждения: ").strip() != "СБРОС":
            print("Сброс отменён.")
            return
        with self.connection.transaction():
            self.db_drop()
            self.db_init()
            self.db_insert_somethings()
        print("Таблицы пересозданы, добавлены 6 пользователей и 6 анкет.")

    def main_cycle(self):
        print("Сессионный проект — вариант 24: пользователи и анкеты")
        self.action(self.db_init)
        # db_init не возвращает значения. Если подключение недоступно,
        # операции в меню всё равно завернуты в понятные сообщения.
        while True:
            print("\n1 — пользователи и анкеты")
            print("2 — создать таблицы (без удаления данных)")
            print("3 — сбросить две таблицы и заполнить примерами")
            print("9 — выход")
            choice = input("=> ").strip()
            if choice == "9":
                print("До свидания!")
                return
            if choice == "1":
                result = self.action(self.show_people)
                if result is True:
                    print("До свидания!")
                    return
            elif choice == "2":
                if self.action(self.db_init) is not FAILED:
                    print("Таблицы готовы. Существующие данные сохранены.")
            elif choice == "3":
                self.action(self.reset_and_demo)
            else:
                print("Неизвестная команда. Выберите пункт меню.")


def main():
    try:
        app = Main()
        app.main_cycle()
        app.connection.close()
    except (KeyboardInterrupt, EOFError):
        print("\nРабота завершена пользователем.")
    except (OSError, ValueError, yaml.YAMLError) as exc:
        print(f"Ошибка конфигурации: {exc}")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
