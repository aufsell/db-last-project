"""Настройки PostgreSQL: config.yaml, с возможностью переопределения через PG*.
Пароль не следует сохранять в репозитории: используйте переменную PGPASSWORD.
"""

import os
from pathlib import Path

import yaml


class ProjectConfig:
    def __init__(self):
        path = Path(__file__).with_name("config.yaml")
        with path.open(encoding="utf-8") as file:
            config = yaml.safe_load(file) or {}

        self.dbname = os.getenv("PGDATABASE", config.get("dbname", "postgres"))
        self.user = os.getenv("PGUSER", config.get("user", "postgres"))
        self.password = os.getenv("PGPASSWORD", config.get("password", "")) or ""
        self.host = os.getenv("PGHOST", config.get("host", "localhost"))
        self.port = os.getenv("PGPORT", str(config.get("port", 5432)))
        self.schema = config.get("schema", "public")
        if not isinstance(self.schema, str) or not self.schema:
            raise ValueError("В config.yaml не указано имя схемы PostgreSQL")
