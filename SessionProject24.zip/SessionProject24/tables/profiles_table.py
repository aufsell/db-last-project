"""Таблица profiles из ДЗ 1: одна анкета на одного пользователя.

Для автономного проекта с двумя таблицами housing_type_id из исходной ДЗ
заменён на читаемое поле housing_type; внешнего справочника здесь нет.
"""

from psycopg2 import sql

from dbtable import DbTable


class ProfilesTable(DbTable):
    table_name = "profiles"

    def __init__(self, dbconn, users_table):
        super().__init__(dbconn)
        self.users_table = users_table

    def create(self):
        self.query(sql.SQL("""
            CREATE TABLE IF NOT EXISTS {} (
                user_id BIGINT PRIMARY KEY REFERENCES {}(user_id) ON DELETE CASCADE,
                about_me TEXT NOT NULL CHECK (length(btrim(about_me)) > 0),
                hobbies TEXT NOT NULL CHECK (length(btrim(hobbies)) > 0),
                housing_type VARCHAR(100) NOT NULL
                    CHECK (length(btrim(housing_type)) > 0)
            )
        """).format(self.table, self.users_table.table))

    def drop(self):
        self.query(sql.SQL("DROP TABLE IF EXISTS {}").format(self.table))

    def all_by_user_id(self, user_id):
        return self.query(sql.SQL("""
            SELECT user_id, about_me, hobbies, housing_type
            FROM {} WHERE user_id = %s
        """).format(self.table), (user_id,), mode="all")

    def insert_one(self, user_id, data):
        self.query(sql.SQL("""
            INSERT INTO {} (user_id, about_me, hobbies, housing_type)
            VALUES (%s, %s, %s, %s)
        """).format(self.table), (
            user_id, data["about_me"], data["hobbies"], data["housing_type"]
        ))

    def update_one(self, user_id, data):
        row = self.query(sql.SQL("""
            UPDATE {} SET about_me = %s, hobbies = %s, housing_type = %s
            WHERE user_id = %s RETURNING user_id
        """).format(self.table), (
            data["about_me"], data["hobbies"], data["housing_type"], user_id
        ), mode="one")
        return row is not None

    def delete_one(self, user_id):
        row = self.query(sql.SQL("DELETE FROM {} WHERE user_id = %s RETURNING user_id").format(
            self.table
        ), (user_id,), mode="one")
        return row is not None
