"""Таблица users из ДЗ 1: операции с пользователями."""

from psycopg2 import sql

from dbtable import DbTable


class UsersTable(DbTable):
    table_name = "users"

    def create(self):
        query = sql.SQL("""
            CREATE TABLE IF NOT EXISTS {} (
                user_id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
                login VARCHAR(50) NOT NULL UNIQUE,
                password_hash TEXT NOT NULL,
                name VARCHAR(100) NOT NULL,
                gender VARCHAR(30) NOT NULL,
                birth_date DATE NOT NULL,
                country VARCHAR(100) NOT NULL,
                city VARCHAR(100) NOT NULL,
                email VARCHAR(254) NOT NULL UNIQUE,
                last_visit TIMESTAMPTZ,
                rating_position INTEGER,
                CONSTRAINT users_rating_position_check
                    CHECK (rating_position IS NULL OR rating_position > 0)
            )
        """).format(self.table)
        self.query(query)

    def drop(self):
        self.query(sql.SQL("DROP TABLE IF EXISTS {}").format(self.table))

    def count(self):
        result = self.query(sql.SQL("SELECT COUNT(*) AS total FROM {}").format(self.table), mode="one")
        return result["total"]

    def page(self, limit, offset):
        return self.query(sql.SQL("""
            SELECT user_id, login, name, gender, birth_date, country, city,
                   email, last_visit, rating_position
            FROM {} ORDER BY user_id LIMIT %s OFFSET %s
        """).format(self.table), (limit, offset), mode="all")

    def get(self, user_id):
        return self.query(sql.SQL("""
            SELECT user_id, login, name, gender, birth_date, country, city,
                   email, last_visit, rating_position
            FROM {} WHERE user_id = %s
        """).format(self.table), (user_id,), mode="one")

    def insert_one(self, data):
        return self.query(sql.SQL("""
            INSERT INTO {} (
                login, password_hash, name, gender, birth_date,
                country, city, email, last_visit, rating_position
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            RETURNING user_id
        """).format(self.table), (
            data["login"], data["password_hash"], data["name"],
            data["gender"], data["birth_date"], data["country"],
            data["city"], data["email"], data["last_visit"],
            data["rating_position"],
        ), mode="one")["user_id"]

    def update_one(self, user_id, data):
        # Фиксированный список полей исключает SQL-инъекции через имена колонок.
        permitted = (
            "login", "name", "gender", "birth_date", "country", "city",
            "email", "last_visit", "rating_position", "password_hash",
        )
        items = [(field, data[field]) for field in permitted if field in data]
        if not items:
            return True
        assignments = sql.SQL(", ").join(
            sql.SQL("{} = %s").format(sql.Identifier(key)) for key, _ in items
        )
        query = sql.SQL("UPDATE {} SET {} WHERE user_id = %s RETURNING user_id").format(
            self.table, assignments
        )
        row = self.query(query, tuple(value for _, value in items) + (user_id,), mode="one")
        return row is not None

    def delete_one(self, user_id):
        # Анкета удалится автоматически за счёт ON DELETE CASCADE.
        row = self.query(sql.SQL("DELETE FROM {} WHERE user_id = %s RETURNING user_id").format(
            self.table
        ), (user_id,), mode="one")
        return row is not None
