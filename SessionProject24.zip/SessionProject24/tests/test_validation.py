"""Тесты проверки ввода: запуск python -m unittest discover -s tests -v"""

import sys
from pathlib import Path
import unittest
from datetime import date

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import validation


class TestValidation(unittest.TestCase):
    def test_login(self):
        self.assertEqual(validation.login(" anna-smirnova "), "anna-smirnova")
        for value in ("", "ab", "name with space", "@admin", "а" * 3, "a" * 51):
            with self.subTest(value=value), self.assertRaises(ValueError):
                validation.login(value)

    def test_email(self):
        self.assertEqual(validation.email(" maria-k@example.com "), "maria-k@example.com")
        for value in ("wrong", "a@b", "a @example.com", "a@@example.com"):
            with self.subTest(value=value), self.assertRaises(ValueError):
                validation.email(value)

    def test_text(self):
        self.assertEqual(validation.plain_text(" Привет ", "Текст", 10), "Привет")
        for value in ("   ", "12345678901"):
            with self.assertRaises(ValueError):
                validation.plain_text(value, "Текст", 10)

    def test_dates(self):
        self.assertEqual(validation.birth_date("2000-01-01"), date(2000, 1, 1))
        for value in ("20.01.2000", "2000-02-31", "2999-01-01"):
            with self.subTest(value=value), self.assertRaises(ValueError):
                validation.birth_date(value)

    def test_datetime(self):
        self.assertEqual(validation.last_visit("2026-11-20 12:00+03:00").hour, 12)
        for value in ("yesterday", "2026-11-20 12:00"):
            with self.subTest(value=value), self.assertRaises(ValueError):
                validation.last_visit(value)

    def test_rating(self):
        self.assertEqual(validation.rating("5"), 5)
        for value in ("0", "-1", "1.5", "abc", "2147483648"):
            with self.subTest(value=value), self.assertRaises(ValueError):
                validation.rating(value)

    def test_password_hash_salted(self):
        x = validation.hash_password("StrongPass123")
        y = validation.hash_password("StrongPass123")
        self.assertTrue(x.startswith("pbkdf2_sha256$"))
        self.assertNotEqual(x, y)
        with self.assertRaises(ValueError):
            validation.hash_password("short")


if __name__ == "__main__":
    unittest.main()
