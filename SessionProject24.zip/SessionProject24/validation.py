"""Проверка пользовательского ввода до обращения к PostgreSQL."""

from datetime import date, datetime
import hashlib
import re
import secrets


LOGIN = re.compile(r"[A-Za-z0-9_.-]{3,50}\Z")
EMAIL = re.compile(r"[^@\s]+@[^@\s]+\.[^@\s]+\Z")


def plain_text(value, label, limit, allow_blank=False):
    value = value.strip()
    if not value and not allow_blank:
        raise ValueError(f"Поле «{label}» не может быть пустым.")
    if len(value) > limit:
        raise ValueError(f"Поле «{label}» должно содержать не более {limit} символов.")
    return value


def login(value):
    value = value.strip()
    if not LOGIN.fullmatch(value):
        raise ValueError("Логин: 3–50 латинских букв, цифр, точек, дефисов или подчёркиваний.")
    return value


def email(value):
    value = plain_text(value, "Email", 254)
    if not EMAIL.fullmatch(value):
        raise ValueError("Введите email в формате name@example.com.")
    return value


def birth_date(value):
    try:
        result = date.fromisoformat(value.strip())
    except ValueError as error:
        raise ValueError("Дата рождения должна быть в формате ГГГГ-ММ-ДД.") from error
    if result > date.today():
        raise ValueError("Дата рождения не может быть в будущем.")
    return result


def last_visit(value):
    try:
        result = datetime.fromisoformat(value.strip())
    except ValueError as error:
        raise ValueError("Дата посещения: ГГГГ-ММ-ДД ЧЧ:ММ+03:00 (с часовым поясом).") from error
    if result.tzinfo is None or result.utcoffset() is None:
        raise ValueError("Укажите часовой пояс, например +03:00.")
    return result


def rating(value):
    if not value.isdecimal():
        raise ValueError("Место в рейтинге должно быть положительным целым числом.")
    result = int(value)
    if not 1 <= result <= 2147483647:
        raise ValueError("Место в рейтинге должно быть от 1 до 2147483647.")
    return result


def hash_password(value):
    if not 8 <= len(value) <= 1024:
        raise ValueError("Пароль должен содержать от 8 до 1024 символов.")
    salt = secrets.token_bytes(16)
    iterations = 210_000
    digest = hashlib.pbkdf2_hmac("sha256", value.encode("utf-8"), salt, iterations)
    return f"pbkdf2_sha256${iterations}${salt.hex()}${digest.hex()}"
